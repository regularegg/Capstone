﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Doron
public class Sequence : MonoBehaviour
{
    public List<GameObject> MonstersToGenerate;
    public List<GameObject> TreatsToGenerate;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
