﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//NAME: TOSSED
public class EnemyEBehavior : Monster
{
    public GameObject projectilePrefab;
    public int projectilesLeft = 5;
    
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
}
