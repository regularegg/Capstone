﻿using System.Collections;
using System.Collections.Generic;
//using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerData: MonoBehaviour
{
    public int HighestScore;

    //public TextMeshPro scoreShow;
    void Start()
    {
        //scoreShow.text = PlayerPrefs.GetInt("highscore").ToString();
    }
}
